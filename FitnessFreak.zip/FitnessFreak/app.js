let loginpage =(e)=> {
    e.preventDefault()
    let user = e.target[0]
    let pswd = e.target[1]

    if(user.value === "Anjan" &&
        pswd.value === "12345") (
            window.location = './Home.html'
        )
    else {
        let err = "border:solid 2px red";
        user.style.cssText = err;
        pswd.style.cssText = err;
    }
}